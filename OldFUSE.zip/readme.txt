Comienzo/fin del módulo

mirar el tema de las entradas de mkf para dmesg, dd y texto por consola.
lectura de archivos(cat??)

Otras funciones:
rename()    Falla? tengo que checkearla bien para que haga lo que quiero 
            renameGPT hace cosas pero no actualiza hijos en directorio -> fichero
            hay que probarla además de arreglar eso.

Después de esto, testeos...

Info extra
Los archivos se borran cuando se abren y se vuelven a generar cuando se cierra (se puede hacer sleep para probarlo)